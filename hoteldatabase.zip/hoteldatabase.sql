-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Tempo de geração: 11-Dez-2022 às 23:19
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `hoteldatabase`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `cli_id` int(11) NOT NULL,
  `cli_nome` varchar(120) NOT NULL,
  `cli_email` varchar(120) NOT NULL,
  `cli_image` text NOT NULL DEFAULT 'profile.jpg',
  `cli_senha` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `hotel`
--

CREATE TABLE `hotel` (
  `hot_id` int(11) NOT NULL,
  `hot_nome` varchar(240) NOT NULL,
  `hot_logradouro` varchar(240) NOT NULL,
  `hot_numero` int(5) NOT NULL,
  `hot_bairro` varchar(240) NOT NULL,
  `hot_cep` int(8) NOT NULL,
  `hot_cidade` varchar(100) NOT NULL,
  `hot_uf` varchar(100) NOT NULL,
  `hot_image` varchar(200) DEFAULT NULL,
  `hot_wifi` tinyint(1) NOT NULL,
  `hot_cafe` tinyint(1) NOT NULL,
  `hot_pet` tinyint(1) NOT NULL,
  `hot_preco` double NOT NULL,
  `hot_nota` double NOT NULL,
  `hot_descricao` varchar(200) NOT NULL,
  `hot_comodidades` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`hot_comodidades`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `hotel`
--

INSERT INTO `hotel` (`hot_id`, `hot_nome`, `hot_logradouro`, `hot_numero`, `hot_bairro`, `hot_cep`, `hot_cidade`, `hot_uf`, `hot_image`, `hot_wifi`, `hot_cafe`, `hot_pet`, `hot_preco`, `hot_nota`, `hot_descricao`, `hot_comodidades`) VALUES
(1, 'Orlando - 5 noites Hotel Premium', 'Alameda José das Dores', 100, 'Jardim Alameda', 1918919, 'Suzano', 'SP', 'https://images.unsplash.com/photo-1597466599360-3b9775841aec?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8b3JsYW5kb3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60', 0, 1, 1, 5500, 9.8, 'É um Hotel 5 estrelas, ficando próximo aos principais centros turisticos!', '{\r\n\"comodidades\": [\"Serviço de arrumação diário\",\"Na praia\",\"Restaurantes e 2 bares/lounges\",\"Piscina externa\",\"Terraço na cobertura\",\"Academia\",\"Sauna seca\",\"Sauna a vapor\",\"Barracas de praia grátis\",\"Guarda-sóis\",\"Espreguiçadeiras\",\"Toalhas de praia\"]\r\n}'),
(3, 'California - 5 noites Hotel Premium', 'Rua Brás Santos', 90, 'Karasuno', 86595023, 'Uberlandia', 'MG', 'https://images.unsplash.com/photo-1619083382085-9452906b7157?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fGNhbGlmb3JuaWF8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60', 1, 0, 0, 7500, 9.5, '5 Noites em hotel com pontos turisticos proximos.', '{\r\n\"comodidades\": [\"Serviço de arrumação diário\",\"Na praia\",\"Restaurantes e 2 bares/lounges\",\"Piscina externa\",\"Terraço na cobertura\",\"Academia\",\"Sauna seca\",\"Sauna a vapor\",\"Barracas de praia grátis\",\"Guarda-sóis\",\"Espreguiçadeiras\",\"Toalhas de praia\"]\r\n}'),
(4, 'Londres - 10 noites Hotel Premium', 'Rua Laranja', 80, 'Caracas', 86495, 'Duque de Caxias', 'RJ', 'https://images.unsplash.com/photo-1486299267070-83823f5448dd?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8bG9uZHJlcyUyMGJpZyUyMGJlbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60', 1, 1, 1, 10000, 10, '10 noites em hotel luxuoso em Londres', '{\r\n\"comodidades\": [\"Serviço de arrumação diário\",\"Na praia\",\"Restaurantes e 2 bares/lounges\",\"Piscina externa\",\"Terraço na cobertura\",\"Academia\",\"Sauna seca\",\"Sauna a vapor\",\"Barracas de praia grátis\",\"Guarda-sóis\",\"Espreguiçadeiras\",\"Toalhas de praia\"]\r\n}'),
(5, 'Itália - 5 noites Hotel Premium', 'Italiano', 50, 'Jalapão', 6505231, 'Recife', 'PE', 'https://images.unsplash.com/photo-1552751118-d3cde54807de?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8aXRhbGlhfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60', 1, 0, 1, 6200, 9.2, '5 noites em um Hotel luxuoso na Itália', '{\r\n\"comodidades\": [\"Serviço de arrumação diário\",\"Na praia\",\"Restaurantes e 2 bares/lounges\",\"Piscina externa\",\"Terraço na cobertura\",\"Academia\",\"Sauna seca\",\"Sauna a vapor\",\"Barracas de praia grátis\",\"Guarda-sóis\",\"Espreguiçadeiras\",\"Toalhas de praia\"]\r\n}'),
(6, 'França - 15 noites Hotel Premium', 'Franch', 10, 'Japones', 865923, 'Gramado', 'RS', 'https://images.unsplash.com/photo-1431274172761-fca41d930114?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8cGFyaXN8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60', 1, 1, 1, 12000, 10, '15 noites na França em hotel em frente da torre eiffel', '{\r\n\"comodidades\": [\"Serviço de arrumação diário\",\"Na praia\",\"Restaurantes e 2 bares/lounges\",\"Piscina externa\",\"Terraço na cobertura\",\"Academia\",\"Sauna seca\",\"Sauna a vapor\",\"Barracas de praia grátis\",\"Guarda-sóis\",\"Espreguiçadeiras\",\"Toalhas de praia\"]\r\n}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `reserva`
--

CREATE TABLE `reserva` (
  `cli_id` int(11) NOT NULL,
  `hot_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  `res_data_entrada` date NOT NULL,
  `res_data_saida` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`cli_id`);

--
-- Índices para tabela `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`hot_id`);

--
-- Índices para tabela `reserva`
--
ALTER TABLE `reserva`
  ADD PRIMARY KEY (`res_id`),
  ADD KEY `cli_id` (`cli_id`),
  ADD KEY `hot_id` (`hot_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `cli_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `hotel`
--
ALTER TABLE `hotel`
  MODIFY `hot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `reserva`
--
ALTER TABLE `reserva`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `reserva`
--
ALTER TABLE `reserva`
  ADD CONSTRAINT `reserva_ibfk_1` FOREIGN KEY (`cli_id`) REFERENCES `cliente` (`cli_id`),
  ADD CONSTRAINT `reserva_ibfk_2` FOREIGN KEY (`hot_id`) REFERENCES `hotel` (`hot_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
